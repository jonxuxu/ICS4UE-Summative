package client;

/**
 * Status.java
 * This is
 *
 * @author Will Jeong
 * @version 1.0
 * @since 2019-05-21
 */

public class Status {
   private int statusID;
   Status (int statusID){
      this.statusID=statusID;
   }
}
