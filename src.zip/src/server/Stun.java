package server;
class Stun extends Status{
  Stun(int duration){
    super(duration);
  }
}