package server;
class Illuminated extends Status{
  Illuminated(int duration){
    super(duration);
  }
}