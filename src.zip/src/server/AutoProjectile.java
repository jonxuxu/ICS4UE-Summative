package server;
class AutoProjectile extends Projectile{

  AutoProjectile(int spawnX, int spawnY, int targetX, int targetY, int speed, int range){
    super(spawnX, spawnY, targetX, targetY, speed, range);
    setID(0);
  }
}