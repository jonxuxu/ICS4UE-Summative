package server;
class SafeMarksmanSpaceAOE1 extends AOE{
  SafeMarksmanSpaceAOE1(int x, int y, int duration, int radius){
    super(x,y,duration,radius);
  }
}