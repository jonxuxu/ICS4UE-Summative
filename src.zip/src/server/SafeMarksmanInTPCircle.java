package server;
class SafeMarksmanInTPCircle extends Status{
  private static int DURATION = 1;
  SafeMarksmanInTPCircle(){
    super(1);
  }
}