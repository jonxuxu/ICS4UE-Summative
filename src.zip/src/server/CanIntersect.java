package server;
import java.awt.geom.Area;
public interface CanIntersect{
  public Area getHitbox();
}