package server;
class SafeMarksmanSpaceAOE2 extends AOE{
  SafeMarksmanSpaceAOE2(int x, int y, int duration, int radius){
    super(x,y,duration,radius);
  }
}