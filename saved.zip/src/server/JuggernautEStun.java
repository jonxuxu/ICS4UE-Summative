package server;
class JuggernautEStun extends Stun{
  private static int DURATION = 100;
  private static int ID = 12;
  JuggernautEStun(){
    super(DURATION,ID);
  }
}