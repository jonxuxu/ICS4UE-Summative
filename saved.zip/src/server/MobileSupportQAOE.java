package server;
class MobileSupportQAOE extends AOE{
  private static int RADIUS = 100;
  private static int ID = 6;
  MobileSupportQAOE(int x, int y, int duration){
    super(x,y,duration,RADIUS,ID);
  }
}