package server;
class Illuminated extends Status{
  private static int ID = 4;
  Illuminated(int duration){
    super(duration,ID);
  }
}