package server;

/**
 * HasID.java
 * This is
 *
 * @author Will Jeong
 * @version 1.0
 * @since 2019-05-31
 */

public interface HasID {
   public int getID();
}
