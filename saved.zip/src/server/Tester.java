package server;

public class Tester {
	public static void main(String[] args) {
	    MainMapGenModule gen = new MainMapGenModule();        
	    
	    System.out.println("executed");
	  }
}
