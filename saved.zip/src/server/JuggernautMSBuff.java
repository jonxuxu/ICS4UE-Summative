package server;
class JuggernautMSBuff extends MSBuff{
  private static int STRENGTH = 3;
  private static int DURATION = 2;
  JuggernautMSBuff(){
    super(STRENGTH, DURATION);
  }
}