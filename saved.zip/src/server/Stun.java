package server;
class Stun extends Status{
  Stun(int duration, int id){
    super(duration, id);
  }
}