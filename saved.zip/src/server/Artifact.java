package server;

public class Artifact {
    private boolean isHeld;

}
