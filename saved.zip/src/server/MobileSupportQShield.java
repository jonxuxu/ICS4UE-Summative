package server;
class MobileSupportQShield extends Shield{
  private static int STRENGTH = 50;
  private static int DURATION = 100;
  MobileSupportQShield(){
    super(STRENGTH, DURATION);
  }
}