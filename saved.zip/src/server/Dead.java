package server;
class Dead extends Stun{
  private static int DURATION = 100;
  private static int ID = 1;
  Dead(){
    super(DURATION,ID);
  }
}