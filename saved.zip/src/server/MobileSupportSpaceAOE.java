package server;
class MobileSupportSpaceAOE extends AOE{
  private static int DURATION = 300;
  private static int RADIUS = 100;
  private static int ID = 9;
  MobileSupportSpaceAOE(int x, int y){
    super(x,y,DURATION,RADIUS,ID);
  }
}
    