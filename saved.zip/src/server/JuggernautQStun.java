package server;
class JuggernautQStun extends Stun{
  private static int DURATION = 100;
  private static int ID = 12;
  JuggernautQStun(){
    super(DURATION,ID);
  }
}