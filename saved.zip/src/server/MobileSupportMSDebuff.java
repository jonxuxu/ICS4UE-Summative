package server;
class MobileSupportMSDebuff extends MSBuff{
  private static int STRENGTH = -3;
  MobileSupportMSDebuff(int duration){
    super(STRENGTH, duration);
  }
}