package server;
class Uncollidable extends Status{
  private static int ID = 10;
  Uncollidable(int duration){
    super(duration,ID);
  }
}