package server;
class GhostPassive extends Status{
  private static int DURATION = 100;
  private static int ID = 3;
  GhostPassive(){
    super(DURATION,ID);
  }
}