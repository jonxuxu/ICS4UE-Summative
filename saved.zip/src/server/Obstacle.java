package server;

import java.awt.Point;


public class Obstacle {
	public Point location;
	public String type;
	public int radius;
	public java.awt.Polygon boundingBox;
	
}
