package server;
class TimeMageQShield extends Shield{
  private static int E_SHIELD_STRENGTH = 100;
  private static int E_SHIELD_DURATION = 100;
  TimeMageQShield(){
    super(E_SHIELD_STRENGTH, E_SHIELD_DURATION);
  }
}