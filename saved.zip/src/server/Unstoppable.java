package server;
class Unstoppable extends Status{
  private static int ID = 11;
  Unstoppable(int duration){
    super(duration, ID);
  }
}