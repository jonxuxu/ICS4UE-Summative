package server;
class MobileSupportEStatus extends Status{
  private static int DURATION = 2;
  private static int ID = -1;
  MobileSupportEStatus(){
    super(DURATION,ID);
  }
}