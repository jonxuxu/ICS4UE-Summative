package server;
class Invisible extends Status{
  private static int ID = 5;
  Invisible(int duration){
    super(duration,ID);
  }
}