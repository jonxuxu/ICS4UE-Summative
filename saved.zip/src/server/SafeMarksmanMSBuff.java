package server;
class SafeMarksmanMSBuff extends MSBuff{
  private static int STRENGTH = 3;
  private static int DURATION = 100;
  SafeMarksmanMSBuff(){
    super(STRENGTH, DURATION);
  }
}