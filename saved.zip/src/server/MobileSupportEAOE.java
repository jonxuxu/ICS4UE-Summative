package server;
class MobileSupportEAOE extends AOE{
  private static int DURATION = 100;
  private static int RADIUS = 100;
  private static int ID = 8;
  MobileSupportEAOE(int x, int y){
    super(x,y,DURATION,RADIUS,ID);
  }
}