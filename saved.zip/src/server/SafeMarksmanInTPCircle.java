package server;
class SafeMarksmanInTPCircle extends Status{
  private static int DURATION = 2;
  private static int ID = -1;
  SafeMarksmanInTPCircle(){
    super(DURATION,ID);
  }
}