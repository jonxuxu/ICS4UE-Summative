package client;

public class Item {
    //ID

}
